#pragma once

namespace bactro::handfx {

void registerModule();
void shutdown();
// Called once per frame from the eglSwapBuffers hook (render thread, GL context current).
void onPostFrame();

} // namespace bactro::handfx
