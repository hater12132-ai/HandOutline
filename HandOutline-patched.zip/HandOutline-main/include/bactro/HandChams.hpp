#pragma once

namespace bactro::handchams {

void registerModule();
void onSignaturesReady();
void shutdown();
void onPostFrame(); // per-frame housekeeping (called from the swap hook)
// HandFx support: paint the first-person hand and held items in a flat magenta key colour so the
// post-process pass can find exactly those pixels. Needs the actor-glint hooks (installs them).
void setKeyMode(bool on);

} // namespace bactro::handchams
