// HandFx - outline / glow / video fill for the first-person hand and held items ONLY.
//
// How it works (no per-draw hooks needed):
//   1. HandChams "key mode" paints the hand + held item in flat magenta (the only things we can reliably reach).
//   2. At eglSwapBuffers (render thread) we copy the finished frame, find the magenta pixels, and redraw them as
//      a colour fill or a looping video, then add an outline + glow around that silhouette.
// Everything is screen-space, depth is irrelevant (the hand is always in front), and nothing is drawn through walls.
#include "bactro/HandFx.hpp"
#include "bactro/HandChams.hpp"
#include "bactro/Status.hpp"

#include <pl/ModMenu.hpp>

#include <EGL/egl.h>
#include <android/log.h>
#include <dlfcn.h>

#include <atomic>
#include <cmath>
#include <chrono>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#define FX_LOGI(...) __android_log_print(ANDROID_LOG_INFO, "BactroNative", __VA_ARGS__)

using GLenum = unsigned int;
using GLuint = unsigned int;
using GLint = int;
using GLsizei = int;
using GLboolean = unsigned char;
using GLfloat = float;
using GLchar = char;

namespace {
constexpr GLenum K_VERTEX_SHADER = 0x8B31, K_FRAGMENT_SHADER = 0x8B30, K_COMPILE_STATUS = 0x8B81,
                 K_LINK_STATUS = 0x8B82, K_TEXTURE_2D = 0x0DE1, K_TEX_MIN = 0x2801, K_TEX_MAG = 0x2800,
                 K_WRAP_S = 0x2802, K_WRAP_T = 0x2803, K_CLAMP = 0x812F, K_REPEAT = 0x2901, K_LINEAR = 0x2601,
                 K_RGB = 0x1907, K_RGBA = 0x1908, K_UBYTE = 0x1401, K_USHORT_565 = 0x8363, K_ARRAY_BUFFER = 0x8892,
                 K_ELEMENT_BUFFER = 0x8893, K_STATIC_DRAW = 0x88E4, K_FLOAT = 0x1406, K_USHORT = 0x1403,
                 K_TRIANGLES = 0x0004, K_TEXTURE12 = 0x84CC, K_TEXTURE13 = 0x84CD, K_BLEND = 0x0BE2,
                 K_DEPTH_TEST = 0x0B71, K_CULL_FACE = 0x0B44, K_SCISSOR = 0x0C11, K_STENCIL = 0x0B90,
                 K_FRAMEBUFFER = 0x8D40, K_FB_BINDING = 0x8CA6, K_CURRENT_PROGRAM = 0x8B8D,
                 K_ACTIVE_TEXTURE = 0x84E0, K_TEX_BINDING_2D = 0x8069, K_ARRAY_BUFFER_BINDING = 0x8894,
                 K_VAO_BINDING = 0x85B5, K_VIEWPORT = 0x0BA2, K_COLOR_MASK = 0x0C23, K_INFO_LOG_LEN = 0x8B84;

// ---- GLES entry points ----
using PFN_V_E = void (*)(GLenum);
#define FXPROC(ret, name, args) ret(*p_##name) args = nullptr;
FXPROC(GLuint, glCreateShader, (GLenum))
FXPROC(void, glShaderSource, (GLuint, GLsizei, const GLchar* const*, const GLint*))
FXPROC(void, glCompileShader, (GLuint))
FXPROC(void, glGetShaderiv, (GLuint, GLenum, GLint*))
FXPROC(void, glGetShaderInfoLog, (GLuint, GLsizei, GLsizei*, GLchar*))
FXPROC(GLuint, glCreateProgram, (void))
FXPROC(void, glAttachShader, (GLuint, GLuint))
FXPROC(void, glLinkProgram, (GLuint))
FXPROC(void, glGetProgramiv, (GLuint, GLenum, GLint*))
FXPROC(GLint, glGetAttribLocation, (GLuint, const GLchar*))
FXPROC(GLint, glGetUniformLocation, (GLuint, const GLchar*))
FXPROC(void, glDeleteShader, (GLuint))
FXPROC(void, glGenTextures, (GLsizei, GLuint*))
FXPROC(void, glBindTexture, (GLenum, GLuint))
FXPROC(void, glTexParameteri, (GLenum, GLenum, GLint))
FXPROC(void, glTexImage2D, (GLenum, GLint, GLint, GLsizei, GLsizei, GLint, GLenum, GLenum, const void*))
FXPROC(void, glTexSubImage2D, (GLenum, GLint, GLint, GLint, GLsizei, GLsizei, GLenum, GLenum, const void*))
FXPROC(void, glCopyTexSubImage2D, (GLenum, GLint, GLint, GLint, GLint, GLint, GLsizei, GLsizei))
FXPROC(void, glGenBuffers, (GLsizei, GLuint*))
FXPROC(void, glBindBuffer, (GLenum, GLuint))
FXPROC(void, glBufferData, (GLenum, long, const void*, GLenum))
FXPROC(void, glUseProgram, (GLuint))
FXPROC(void, glActiveTexture, (GLenum))
FXPROC(void, glUniform1i, (GLint, GLint))
FXPROC(void, glUniform1f, (GLint, GLfloat))
FXPROC(void, glUniform2f, (GLint, GLfloat, GLfloat))
FXPROC(void, glUniform3f, (GLint, GLfloat, GLfloat, GLfloat))
FXPROC(void, glEnableVertexAttribArray, (GLuint))
FXPROC(void, glVertexAttribPointer, (GLuint, GLint, GLenum, GLboolean, GLsizei, const void*))
FXPROC(void, glDrawElements, (GLenum, GLsizei, GLenum, const void*))
FXPROC(void, glViewport, (GLint, GLint, GLsizei, GLsizei))
FXPROC(void, glDisable, (GLenum))
FXPROC(void, glEnable, (GLenum))
FXPROC(GLboolean, glIsEnabled, (GLenum))
FXPROC(void, glGetIntegerv, (GLenum, GLint*))
FXPROC(void, glGetBooleanv, (GLenum, GLboolean*))
FXPROC(void, glColorMask, (GLboolean, GLboolean, GLboolean, GLboolean))
FXPROC(void, glBindFramebuffer, (GLenum, GLuint))
FXPROC(void, glGenVertexArrays, (GLsizei, GLuint*))
FXPROC(void, glBindVertexArray, (GLuint))
FXPROC(GLenum, glGetError, (void))

void logLine(const char* fmt, ...) {
    char buf[200];
    va_list ap;
    va_start(ap, fmt);
    std::vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    bactro::statusLine(buf);
    FX_LOGI("%s", buf);
}

void* glProc(const char* name) {
    if (void* p = reinterpret_cast<void*>(eglGetProcAddress(name))) return p;
    void* lib = dlopen("libGLESv3.so", RTLD_NOW);
    if (!lib) lib = dlopen("libGLESv2.so", RTLD_NOW);
    return lib ? dlsym(lib, name) : nullptr;
}
#define FXLOAD(name) p_##name = reinterpret_cast<decltype(p_##name)>(glProc(#name))

bool loadGl() {
    FXLOAD(glCreateShader); FXLOAD(glShaderSource); FXLOAD(glCompileShader); FXLOAD(glGetShaderiv);
    FXLOAD(glGetShaderInfoLog); FXLOAD(glCreateProgram); FXLOAD(glAttachShader); FXLOAD(glLinkProgram);
    FXLOAD(glGetProgramiv); FXLOAD(glGetAttribLocation); FXLOAD(glGetUniformLocation); FXLOAD(glDeleteShader);
    FXLOAD(glGenTextures); FXLOAD(glBindTexture); FXLOAD(glTexParameteri); FXLOAD(glTexImage2D);
    FXLOAD(glTexSubImage2D); FXLOAD(glCopyTexSubImage2D); FXLOAD(glGenBuffers); FXLOAD(glBindBuffer);
    FXLOAD(glBufferData); FXLOAD(glUseProgram); FXLOAD(glActiveTexture); FXLOAD(glUniform1i); FXLOAD(glUniform1f);
    FXLOAD(glUniform2f); FXLOAD(glUniform3f); FXLOAD(glEnableVertexAttribArray); FXLOAD(glVertexAttribPointer);
    FXLOAD(glDrawElements); FXLOAD(glViewport); FXLOAD(glDisable); FXLOAD(glEnable); FXLOAD(glIsEnabled);
    FXLOAD(glGetIntegerv); FXLOAD(glGetBooleanv); FXLOAD(glColorMask); FXLOAD(glBindFramebuffer);
    FXLOAD(glGenVertexArrays); FXLOAD(glBindVertexArray); FXLOAD(glGetError);
    return p_glCreateShader && p_glUseProgram && p_glCopyTexSubImage2D && p_glDrawElements && p_glTexSubImage2D &&
           p_glBindFramebuffer && p_glGenVertexArrays && p_glBindVertexArray && p_glIsEnabled && p_glGetIntegerv;
}

// ---- Shaders (GLSL ES 1.00) ----
const char* kVS = R"(
attribute vec4 aPosition;
attribute vec2 aTexCoord;
varying vec2 vUv;
void main() {
    gl_Position = aPosition;
    vUv = aTexCoord;
}
)";

const char* kFS = R"(
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec2 vUv;
uniform sampler2D uScene;
uniform sampler2D uVideo;
uniform vec2  uTexel;      // 1 / framebuffer size
uniform vec3  uKey;        // normalised key colour direction
uniform float uTol;        // cosine threshold, higher = stricter
uniform vec3  uOutline;    // outline + glow colour
uniform float uWidth;      // outline width in pixels (0 = no outline)
uniform float uGlow;       // 0..1
uniform float uVideoOn;    // 1 = video fill, 0 = solid colour fill
uniform vec3  uFillColor;
uniform float uShade;      // how much of the hand's own shading to keep
uniform float uDebug;      // 1 = show the detected mask in green

float maskOf(vec3 c) {
    float m = max(max(c.r, c.g), c.b);
    float n = min(min(c.r, c.g), c.b);
    float sat = (m - n) / max(m, 0.02);
    float d = dot(normalize(c + vec3(0.0001)), uKey);
    // the key has (almost) no green: this rejects pink / purple / magenta blocks that share its hue
    float gate = 1.0 - smoothstep(0.22, 0.40, c.g / max(min(c.r, c.b), 0.02));
    return smoothstep(uTol - 0.03, uTol + 0.02, d) * smoothstep(0.55, 0.75, sat) * gate * step(0.05, m);
}

#define EDGE(dx, dy) edge = max(edge, maskOf(texture2D(uScene, vUv + vec2(dx, dy) * uTexel * uWidth).rgb)); edge = max(edge, maskOf(texture2D(uScene, vUv + vec2(dx, dy) * uTexel * uWidth * 0.5).rgb));
#define GLOW(dx, dy) glow = max(glow, maskOf(texture2D(uScene, vUv + vec2(dx, dy) * uTexel * uWidth * 2.6).rgb));

void main() {
    vec3 c = texture2D(uScene, vUv).rgb;
    float m0 = maskOf(c);
    if (uDebug > 0.5) {
        gl_FragColor = vec4(mix(c, vec3(0.0, 1.0, 0.0), m0), 1.0);
        return;
    }
    vec3 outside = c;
    if (m0 < 0.999 && uWidth > 0.5) {
        float edge = 0.0;
        float glow = 0.0;
        EDGE(1.0, 0.0) EDGE(0.7071, 0.7071) EDGE(0.0, 1.0) EDGE(-0.7071, 0.7071)
        EDGE(-1.0, 0.0) EDGE(-0.7071, -0.7071) EDGE(0.0, -1.0) EDGE(0.7071, -0.7071)
        if (uGlow > 0.01) {
            GLOW(1.0, 0.0) GLOW(0.7071, 0.7071) GLOW(0.0, 1.0) GLOW(-0.7071, 0.7071)
            GLOW(-1.0, 0.0) GLOW(-0.7071, -0.7071) GLOW(0.0, -1.0) GLOW(0.7071, -0.7071)
        }
        outside = mix(outside, uOutline, glow * uGlow * 0.55);
        outside = mix(outside, uOutline, edge);
    }
    if (m0 <= 0.001) {
        gl_FragColor = vec4(outside, 1.0);
        return;
    }
    vec3 fill = uFillColor;
    if (uVideoOn > 0.5) fill = texture2D(uVideo, vec2(vUv.x, 1.0 - vUv.y)).rgb;
    float lum = clamp(max(max(c.r, c.g), c.b), 0.0, 1.0);
    fill *= mix(1.0, lum, uShade);
    float inside = smoothstep(0.35, 0.65, m0);
    gl_FragColor = vec4(mix(outside, fill, inside), 1.0);
}
)";

// ---- Video (pre-baked .bvid: "BVID", ver, w, h, frames, fps, then RGB565 frames) ----
struct Video {
    int w = 0, h = 0, frames = 0, fps = 20;
    std::vector<std::uint8_t> data;
};
constexpr const char* kDir = "/storage/emulated/0/Android/media/org.levimc.launcher/bactro_videos";

std::shared_ptr<const Video> loadVideoFile(int idx) {
    char path[256];
    std::snprintf(path, sizeof(path), "%s/video%d.bvid", kDir, idx);
    FILE* f = std::fopen(path, "rb");
    if (!f) {
        logLine("HandFx: %s not found", path);
        return nullptr;
    }
    std::uint32_t hdr[6] = {0};
    if (std::fread(hdr, 4, 6, f) != 6 || std::memcmp(&hdr[0], "BVID", 4) != 0 || hdr[1] != 1) {
        std::fclose(f);
        logLine("HandFx: video%d.bvid has a bad header", idx);
        return nullptr;
    }
    auto v = std::make_shared<Video>();
    v->w = static_cast<int>(hdr[2]);
    v->h = static_cast<int>(hdr[3]);
    v->frames = static_cast<int>(hdr[4]);
    v->fps = static_cast<int>(hdr[5]);
    if (v->w < 2 || v->h < 2 || v->w > 1024 || v->h > 1024 || (v->w & 1) || v->frames < 1 || v->frames > 4000 ||
        v->fps < 1 || v->fps > 120) {
        std::fclose(f);
        logLine("HandFx: video%d.bvid has bad dimensions", idx);
        return nullptr;
    }
    const size_t bytes = static_cast<size_t>(v->w) * v->h * 2 * v->frames;
    v->data.resize(bytes);
    const size_t got = std::fread(v->data.data(), 1, bytes, f);
    std::fclose(f);
    if (got != bytes) {
        logLine("HandFx: video%d.bvid is truncated", idx);
        return nullptr;
    }
    logLine("HandFx: loaded video%d (%dx%d, %d frames @ %d fps)", idx, v->w, v->h, v->frames, v->fps);
    return v;
}

// ---- Settings ----
std::atomic_bool g_enabled{false};
std::atomic_bool g_outlineOn{true};
std::atomic<float> g_or{1.0f}, g_og{0.25f}, g_ob{0.0f};
std::atomic<float> g_width{3.0f};
std::atomic<float> g_glow{0.6f};
std::atomic<int> g_fillMode{0};   // 0 = solid colour, 1..3 = video1..3
std::atomic<float> g_shade{0.6f};
std::atomic<float> g_tol{0.93f};
std::atomic_bool g_debug{false};

std::mutex g_vmu;
std::shared_ptr<const Video> g_video; // guarded by g_vmu
int g_videoIdx = 0;

// ---- GL state (render thread only) ----
bool g_glTried = false, g_glReady = false;
GLuint g_prog = 0, g_texScene = 0, g_texVideo = 0, g_vbo = 0, g_ibo = 0, g_vao = 0;
GLint g_aPos = -1, g_aUv = -1, uScene = -1, uVideo = -1, uTexel = -1, uKey = -1, uTol = -1, uOutline = -1,
      uWidth = -1, uGlow = -1, uVideoOn = -1, uFillColor = -1, uShade = -1, uDebug = -1;
int g_w = 0, g_h = 0;
int g_vidW = 0, g_vidH = 0, g_vidFrameUploaded = -1;
const Video* g_vidUploadedFrom = nullptr;

bool compile(GLenum type, const char* src, GLuint& out, const char* what) {
    out = p_glCreateShader(type);
    p_glShaderSource(out, 1, &src, nullptr);
    p_glCompileShader(out);
    GLint ok = 0;
    p_glGetShaderiv(out, K_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[160] = {0};
        GLsizei n = 0;
        if (p_glGetShaderInfoLog) p_glGetShaderInfoLog(out, sizeof(log) - 1, &n, log);
        for (char& ch : log) if (ch == '\n' || ch == '\r') ch = ' ';
        logLine("HandFx: %s shader compile FAILED: %.150s", what, log);
    }
    return ok != 0;
}

bool initGl() {
    if (g_glReady) return true;
    if (g_glTried) return false; // one attempt only: never retry-spam a broken driver
    g_glTried = true;
    if (!loadGl()) {
        logLine("HandFx: GLES3 entry points missing - effect disabled");
        return false;
    }
    GLuint vs = 0, fs = 0;
    if (!compile(K_VERTEX_SHADER, kVS, vs, "vertex") || !compile(K_FRAGMENT_SHADER, kFS, fs, "fragment")) return false;
    g_prog = p_glCreateProgram();
    p_glAttachShader(g_prog, vs);
    p_glAttachShader(g_prog, fs);
    p_glLinkProgram(g_prog);
    GLint linked = 0;
    p_glGetProgramiv(g_prog, K_LINK_STATUS, &linked);
    p_glDeleteShader(vs);
    p_glDeleteShader(fs);
    if (!linked) {
        logLine("HandFx: shader link FAILED");
        return false;
    }
    g_aPos = p_glGetAttribLocation(g_prog, "aPosition");
    g_aUv = p_glGetAttribLocation(g_prog, "aTexCoord");
#define U(n) u##n = p_glGetUniformLocation(g_prog, "u" #n)
    U(Scene); U(Video); U(Texel); U(Key); U(Tol); U(Outline); U(Width); U(Glow); U(VideoOn); U(FillColor); U(Shade);
    U(Debug);
#undef U
    // Remember what the game had bound so we never disturb it while creating our objects.
    GLint prevTex = 0, prevAb = 0, prevVao = 0, prevAct = 0;
    p_glGetIntegerv(K_ACTIVE_TEXTURE, &prevAct);
    p_glActiveTexture(K_TEXTURE12);
    p_glGetIntegerv(K_TEX_BINDING_2D, &prevTex);
    p_glGetIntegerv(K_ARRAY_BUFFER_BINDING, &prevAb);
    p_glGetIntegerv(K_VAO_BINDING, &prevVao);

    p_glGenTextures(1, &g_texScene);
    p_glGenTextures(1, &g_texVideo);
    for (GLuint t : {g_texScene, g_texVideo}) {
        p_glBindTexture(K_TEXTURE_2D, t);
        p_glTexParameteri(K_TEXTURE_2D, K_TEX_MIN, K_LINEAR);
        p_glTexParameteri(K_TEXTURE_2D, K_TEX_MAG, K_LINEAR);
        p_glTexParameteri(K_TEXTURE_2D, K_WRAP_S, K_CLAMP);
        p_glTexParameteri(K_TEXTURE_2D, K_WRAP_T, K_CLAMP);
    }
    // Own VAO so the game's vertex state is never touched.
    p_glGenVertexArrays(1, &g_vao);
    p_glBindVertexArray(g_vao);
    const GLfloat verts[] = {-1.f, 1.f, 0.f, 1.f, -1.f, -1.f, 0.f, 0.f, 1.f, -1.f, 1.f, 0.f, 1.f, 1.f, 1.f, 1.f};
    const unsigned short idx[] = {0, 1, 2, 0, 2, 3};
    p_glGenBuffers(1, &g_vbo);
    p_glBindBuffer(K_ARRAY_BUFFER, g_vbo);
    p_glBufferData(K_ARRAY_BUFFER, sizeof(verts), verts, K_STATIC_DRAW);
    p_glGenBuffers(1, &g_ibo);
    p_glBindBuffer(K_ELEMENT_BUFFER, g_ibo); // stored in our VAO
    p_glBufferData(K_ELEMENT_BUFFER, sizeof(idx), idx, K_STATIC_DRAW);
    if (g_aPos >= 0) {
        p_glEnableVertexAttribArray(static_cast<GLuint>(g_aPos));
        p_glVertexAttribPointer(static_cast<GLuint>(g_aPos), 2, K_FLOAT, 0, 4 * sizeof(GLfloat), nullptr);
    }
    if (g_aUv >= 0) {
        p_glEnableVertexAttribArray(static_cast<GLuint>(g_aUv));
        p_glVertexAttribPointer(static_cast<GLuint>(g_aUv), 2, K_FLOAT, 0, 4 * sizeof(GLfloat),
                                reinterpret_cast<const void*>(2 * sizeof(GLfloat)));
    }
    p_glBindVertexArray(static_cast<GLuint>(prevVao));
    p_glBindBuffer(K_ARRAY_BUFFER, static_cast<GLuint>(prevAb));
    p_glBindTexture(K_TEXTURE_2D, static_cast<GLuint>(prevTex));
    p_glActiveTexture(static_cast<GLenum>(prevAct));
    g_glReady = true;
    logLine("HandFx: GL ready");
    return true;
}

struct Saved {
    GLint prog = 0, act = 0, tex12 = 0, tex13 = 0, ab = 0, vao = 0, fb = 0, vp[4] = {0, 0, 0, 0};
    GLboolean blend = 0, depth = 0, cull = 0, scissor = 0, stencil = 0, cm[4] = {1, 1, 1, 1};
};

void save(Saved& s) {
    p_glGetIntegerv(K_CURRENT_PROGRAM, &s.prog);
    p_glGetIntegerv(K_ACTIVE_TEXTURE, &s.act);
    p_glActiveTexture(K_TEXTURE12);
    p_glGetIntegerv(K_TEX_BINDING_2D, &s.tex12);
    p_glActiveTexture(K_TEXTURE13);
    p_glGetIntegerv(K_TEX_BINDING_2D, &s.tex13);
    p_glGetIntegerv(K_ARRAY_BUFFER_BINDING, &s.ab);
    p_glGetIntegerv(K_VAO_BINDING, &s.vao);
    p_glGetIntegerv(K_FB_BINDING, &s.fb);
    p_glGetIntegerv(K_VIEWPORT, s.vp);
    s.blend = p_glIsEnabled(K_BLEND);
    s.depth = p_glIsEnabled(K_DEPTH_TEST);
    s.cull = p_glIsEnabled(K_CULL_FACE);
    s.scissor = p_glIsEnabled(K_SCISSOR);
    s.stencil = p_glIsEnabled(K_STENCIL);
    if (p_glGetBooleanv) p_glGetBooleanv(K_COLOR_MASK, s.cm);
}

void restore(const Saved& s) {
    p_glActiveTexture(K_TEXTURE12);
    p_glBindTexture(K_TEXTURE_2D, static_cast<GLuint>(s.tex12));
    p_glActiveTexture(K_TEXTURE13);
    p_glBindTexture(K_TEXTURE_2D, static_cast<GLuint>(s.tex13));
    p_glActiveTexture(static_cast<GLenum>(s.act));
    p_glUseProgram(static_cast<GLuint>(s.prog));
    p_glBindVertexArray(static_cast<GLuint>(s.vao));
    p_glBindBuffer(K_ARRAY_BUFFER, static_cast<GLuint>(s.ab));
    p_glBindFramebuffer(K_FRAMEBUFFER, static_cast<GLuint>(s.fb));
    p_glViewport(s.vp[0], s.vp[1], s.vp[2], s.vp[3]);
    auto setEn = [](GLenum cap, GLboolean on) { if (on) p_glEnable(cap); else p_glDisable(cap); };
    setEn(K_BLEND, s.blend);
    setEn(K_DEPTH_TEST, s.depth);
    setEn(K_CULL_FACE, s.cull);
    setEn(K_SCISSOR, s.scissor);
    setEn(K_STENCIL, s.stencil);
    p_glColorMask(s.cm[0], s.cm[1], s.cm[2], s.cm[3]);
}

void ensureSceneTex(int w, int h) {
    if (w == g_w && h == g_h) return;
    g_w = w;
    g_h = h;
    p_glActiveTexture(K_TEXTURE12);
    p_glBindTexture(K_TEXTURE_2D, g_texScene);
    p_glTexImage2D(K_TEXTURE_2D, 0, K_RGB, w, h, 0, K_RGB, K_UBYTE, nullptr);
}

void uploadVideoFrame(const std::shared_ptr<const Video>& v) {
    if (!v) return;
    const double t = std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
    const int frame = static_cast<int>(t * v->fps) % v->frames;
    p_glActiveTexture(K_TEXTURE13);
    p_glBindTexture(K_TEXTURE_2D, g_texVideo);
    if (g_vidUploadedFrom != v.get() || g_vidW != v->w || g_vidH != v->h) {
        p_glTexImage2D(K_TEXTURE_2D, 0, K_RGB, v->w, v->h, 0, K_RGB, K_USHORT_565, nullptr);
        g_vidW = v->w;
        g_vidH = v->h;
        g_vidUploadedFrom = v.get();
        g_vidFrameUploaded = -1;
    }
    if (frame == g_vidFrameUploaded) return;
    g_vidFrameUploaded = frame;
    const std::uint8_t* src = v->data.data() + static_cast<size_t>(frame) * v->w * v->h * 2;
    p_glTexSubImage2D(K_TEXTURE_2D, 0, 0, 0, v->w, v->h, K_RGB, K_USHORT_565, src);
}

void renderFrame() {
    if (!initGl()) return;
    EGLDisplay dpy = eglGetCurrentDisplay();
    EGLSurface surf = eglGetCurrentSurface(EGL_DRAW);
    if (dpy == EGL_NO_DISPLAY || surf == EGL_NO_SURFACE) return;
    EGLint w = 0, h = 0;
    eglQuerySurface(dpy, surf, EGL_WIDTH, &w);
    eglQuerySurface(dpy, surf, EGL_HEIGHT, &h);
    if (w <= 0 || h <= 0) return;

    std::shared_ptr<const Video> vid;
    const int fillMode = g_fillMode.load(std::memory_order_relaxed);
    if (fillMode > 0) {
        std::lock_guard<std::mutex> lk(g_vmu);
        vid = g_video;
    }

    Saved sv;
    save(sv);

    p_glBindFramebuffer(K_FRAMEBUFFER, 0);
    ensureSceneTex(w, h);
    p_glActiveTexture(K_TEXTURE12);
    p_glBindTexture(K_TEXTURE_2D, g_texScene);
    p_glCopyTexSubImage2D(K_TEXTURE_2D, 0, 0, 0, 0, 0, w, h);
    if (vid) uploadVideoFrame(vid);

    p_glViewport(0, 0, w, h);
    p_glDisable(K_SCISSOR);
    p_glDisable(K_BLEND);
    p_glDisable(K_DEPTH_TEST);
    p_glDisable(K_CULL_FACE);
    p_glDisable(K_STENCIL);
    p_glColorMask(1, 1, 1, 1);

    p_glUseProgram(g_prog);
    p_glUniform1i(uScene, 12);
    p_glUniform1i(uVideo, 13);
    p_glUniform2f(uTexel, 1.f / static_cast<float>(w), 1.f / static_cast<float>(h));
    const float inv = 0.70710678f; // magenta (1,0,1) normalised
    p_glUniform3f(uKey, inv, 0.f, inv);
    p_glUniform1f(uTol, g_tol.load(std::memory_order_relaxed));
    const float orr = g_or.load(std::memory_order_relaxed), og = g_og.load(std::memory_order_relaxed),
                ob = g_ob.load(std::memory_order_relaxed);
    p_glUniform3f(uOutline, orr, og, ob);
    p_glUniform1f(uWidth, g_outlineOn.load(std::memory_order_relaxed) ? g_width.load(std::memory_order_relaxed) : 0.f);
    p_glUniform1f(uGlow, g_glow.load(std::memory_order_relaxed));
    p_glUniform1f(uVideoOn, vid ? 1.f : 0.f);
    p_glUniform3f(uFillColor, orr * 0.55f, og * 0.55f, ob * 0.55f);
    p_glUniform1f(uShade, g_shade.load(std::memory_order_relaxed));
    p_glUniform1f(uDebug, g_debug.load(std::memory_order_relaxed) ? 1.f : 0.f);

    p_glBindVertexArray(g_vao);
    p_glDrawElements(K_TRIANGLES, 6, K_USHORT, nullptr);

    static int s_log = 0;
    if (s_log < 3) {
        const GLenum err = p_glGetError ? p_glGetError() : 0;
        logLine("HandFx: pass drawn %dx%d err=0x%x video=%d", w, h, static_cast<unsigned>(err), vid ? 1 : 0);
        ++s_log;
    }
    restore(sv);
}

// ---- Menu ----
void loadSelectedVideo(int idx) {
    if (idx <= 0) {
        std::lock_guard<std::mutex> lk(g_vmu);
        g_video.reset();
        g_videoIdx = 0;
        return;
    }
    auto v = loadVideoFile(idx);
    std::lock_guard<std::mutex> lk(g_vmu);
    g_video = v;
    g_videoIdx = v ? idx : 0;
}

void onToggle(std::string_view, bool enabled) {
    g_enabled.store(enabled, std::memory_order_release);
    logLine("HandFx %s", enabled ? "ON" : "OFF");
    bactro::handchams::setKeyMode(enabled);
    if (enabled) loadSelectedVideo(g_fillMode.load(std::memory_order_relaxed));
}

float fv(std::string_view v) { return std::stof(std::string(v)); }

void onConfig(std::string_view, std::string_view key, std::string_view value) {
    try {
        const bool on = (value == "true" || value == "1");
        if (key == "outline") g_outlineOn.store(on, std::memory_order_relaxed);
        else if (key == "r") g_or.store(fv(value), std::memory_order_relaxed);
        else if (key == "g") g_og.store(fv(value), std::memory_order_relaxed);
        else if (key == "b") g_ob.store(fv(value), std::memory_order_relaxed);
        else if (key == "width") g_width.store(fv(value), std::memory_order_relaxed);
        else if (key == "glow") g_glow.store(fv(value), std::memory_order_relaxed);
        else if (key == "shade") g_shade.store(fv(value), std::memory_order_relaxed);
        else if (key == "tol") g_tol.store(fv(value), std::memory_order_relaxed);
        else if (key == "debug") g_debug.store(on, std::memory_order_relaxed);
        else if (key == "video") {
            int idx = static_cast<int>(std::lround(fv(value)));
            if (idx < 0) idx = 0;
            if (idx > 3) idx = 3;
            g_fillMode.store(idx, std::memory_order_relaxed);
            if (g_enabled.load(std::memory_order_relaxed)) loadSelectedVideo(idx);
        }
    } catch (...) {
    }
}
} // namespace

namespace bactro::handfx {

void registerModule() {
    pl::modmenu::ModuleBuilder b("bactro.handfx", "Hand FX (outline + video)");
    b.description("Outline, glow and video fill on your first-person hand and held items only. Screen-space, never through walls.")
        .defaultEnabled(false)
        .onToggle(onToggle)
        .onConfigChanged(onConfig);
    b.config("outline", "Outline + glow", pl::modmenu::ConfigType::Toggle, "true", "", "", "");
    b.config("r", "Outline red", pl::modmenu::ConfigType::SliderFloat, "1.00", "0", "1", "");
    b.config("g", "Outline green", pl::modmenu::ConfigType::SliderFloat, "0.25", "0", "1", "");
    b.config("b", "Outline blue", pl::modmenu::ConfigType::SliderFloat, "0.00", "0", "1", "");
    b.config("width", "Outline width (px)", pl::modmenu::ConfigType::SliderFloat, "3", "1", "8", "");
    b.config("glow", "Glow", pl::modmenu::ConfigType::SliderFloat, "0.6", "0", "1", "");
    b.config("video", "Fill: 0 colour, 1-3 video", pl::modmenu::ConfigType::SliderFloat, "0", "0", "3", "");
    b.config("shade", "Keep hand shading", pl::modmenu::ConfigType::SliderFloat, "0.6", "0", "1", "");
    b.config("tol", "Key strictness", pl::modmenu::ConfigType::SliderFloat, "0.93", "0.80", "0.99", "");
    b.config("debug", "Debug: show detected mask (green)", pl::modmenu::ConfigType::Toggle, "false", "", "", "");
    b.registerModule();
}

void shutdown() {
    g_enabled.store(false, std::memory_order_release);
    bactro::handchams::setKeyMode(false);
}

void onPostFrame() {
    if (!g_enabled.load(std::memory_order_relaxed)) return;
    try {
        renderFrame();
    } catch (...) {
    }
}

} // namespace bactro::handfx
